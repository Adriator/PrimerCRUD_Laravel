<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\modelPokemon;

class controladorPokemon extends Controller
{
    public function index()
    {
        $pokemons = modelPokemon::all();
        return view('pokemons.index', compact('pokemons'));
    }

    public function create()
    {
        return view('pokemons.create');
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'nombre' => 'required',
            'tipo' => 'required',
            'tamano' => 'required|in:pequeño,mediano,grande',
            'peso' => 'required|numeric',
        ]);

        $pokemon = modelPokemon::findOrFail($id);
        $pokemon->update($request->all());

        return redirect()->route('pokemons.index');
    }

    public function show($id)
    {
        $pokemon = modelPokemon::findOrFail($id);
        return view('pokemons.show', compact('pokemon'));
    }

    public function edit($id)
    {
        $pokemon = modelPokemon::findOrFail($id);
        return view('pokemons.edit', compact('pokemon'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required',
            'tipo' => 'required',
            'tamano' => 'required|in:pequeño,mediano,grande',
            'peso' => 'required|numeric',
        ]);

        modelPokemon::create($request->all());

        return redirect()->route('pokemons.index');
    }

    public function destroy($id)
    {
        $pokemon = modelPokemon::findOrFail($id);
        $pokemon->delete();

        return redirect()->route('pokemons.index');
    }
}

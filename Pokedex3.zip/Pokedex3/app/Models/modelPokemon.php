<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class modelPokemon extends Model
{
    use HasFactory;

    protected $table = 'pokemons';
    
    protected $fillable = ['nombre', 'tipo', 'tamano', 'peso'];
}

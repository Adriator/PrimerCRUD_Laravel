<!-- resources/views/pokemons/create.blade.php -->


    <h1>Crear Pokémon</h1>

    <form action="<?php echo e(route('pokemons.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="nombre">Nombre:</label>
            <input type="text" name="nombre" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="tipo">Tipo:</label>
            <select name="tipo" class="form-control" required>
                <option value="Fuego">Fuego</option>
                <option value="Agua">Agua</option>
                <!-- Agrega más tipos según tus necesidades -->
            </select>
        </div>
        <div class="form-group">
            <label for="tamano">Tamaño:</label>
            <select name="tamano" class="form-control" required>
                <option value="pequeño">Pequeño</option>
                <option value="mediano">Mediano</option>
                <option value="grande">Grande</option>
            </select>
        </div>
        <div class="form-group">
            <label for="peso">Peso:</label>
            <input type="number" name="peso" step="0.01" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success">Guardar</button>
    </form>

<?php /**PATH C:\xampp\htdocs\Pokedex3\resources\views/pokemons/show.blade.php ENDPATH**/ ?>
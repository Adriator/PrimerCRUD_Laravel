<!-- resources/views/pokemons/index.blade.php -->


    <h1>Lista de Pokemons</h1>

    <a href="<?php echo e(route('pokemons.create')); ?>" class="btn btn-primary">Crear Pokémon</a>

    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Tipo</th>
                <th>Tamaño</th>
                <th>Peso</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pokemons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pokemon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($pokemon->id); ?></td>
                    <td><?php echo e($pokemon->nombre); ?></td>
                    <td><?php echo e($pokemon->tipo); ?></td>
                    <td><?php echo e($pokemon->tamano); ?></td>
                    <td><?php echo e($pokemon->peso); ?></td>
                    <td>
                        <a href="<?php echo e(route('pokemons.edit', $pokemon->id)); ?>" class="btn btn-warning">Editar</a>
                        <form action="<?php echo e(route('pokemons.destroy', $pokemon->id)); ?>" method="post" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger" onclick="return confirm('¿Estás seguro?')">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php /**PATH D:\Pokedex3\resources\views/pokemons/index.blade.php ENDPATH**/ ?>
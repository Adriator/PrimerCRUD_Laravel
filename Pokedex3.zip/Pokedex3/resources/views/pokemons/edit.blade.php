<!-- resources/views/pokemons/edit.blade.php -->

<div class="container">
        <h2>Editar Pokemon</h2>
        <form action="{{ route('pokemons.update', $pokemon->id) }}" method="POST">
            @csrf
            @method('PUT')

            <div class="form-group">
                <label for="nombre">Nombre:</label>
                <input type="text" name="nombre" value="{{ old('nombre', $pokemon->nombre) }}" class="form-control" required>
            </div>
            <div class="form-group">
            <label for="tipo">Tipo:</label>
            <select name="tipo" class="form-control" required>
            <option value="Acero">Acero</option>
                <option value="Agua">Agua</option>
                <option value="Bicho">Bicho</option>
                <option value="Dragon">Dragon</option>
                <option value="Electrico">Electrico</option>
                <option value="Fantasma">Fantasma</option>
                <option value="Fuego">Fuego</option>
                <option value="Hada">Hada</option>
                <option value="Hielo">Hielo</option>
                <option value="Lucha">Lucha</option>
                <option value="Normal">Normal</option>
                <option value="Planta">Planta</option>
                <option value="Psiquico">Psiquico</option>
                <option value="Roca">Roca</option>
                <option value="Siniestro">Siniestro</option>
                <option value="Tierra">Tierra</option>
                <option value="Veneno">Veneno</option>
                <option value="Volador">Volador</option>  
            </select>
        </div>
        <div class="form-group">
            <label for="tamano">Tamaño:</label>
            <select name="tamano" class="form-control" required>
                <option value="pequeño">Pequeño</option>
                <option value="mediano">Mediano</option>
                <option value="grande">Grande</option>
            </select>
        </div>
            <div class="form-group">
                <label for="peso">Peso:</label>
                <input type="number" name="peso" value="{{ old('peso', $pokemon->peso) }}" class="form-control" required>
            </div>

            <button type="submit" class="btn btn-primary">Editar Pokemon</button>
        </form>
    </div>
</div>
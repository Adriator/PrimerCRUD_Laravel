<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\controladorPokemon;

Route::resource('pokemons', controladorPokemon::class);

Route::get('/', function () {
    return view('welcome');
});
